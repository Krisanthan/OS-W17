#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ext2.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <sys/mman.h>

int main(int argc, char **argv){
        if(argc != 3 && argc != 4){
                fprintf(stderr, "usage: ext2_mkdir ext2_disk abs_path [-a]");
        }

	int file = open(argv[1], O_RDWR);

	char *disk = (char *)mmap(NULL, 128 * 1024, PROT_READ | PROT_WRITE, MAP_SHARED, file, 0);
        if(disk == MAP_FAILED){
                perror("mmaap");
                exit(1);
        }

        struct ext2_super_block *super_block = (struct ext2_super_block*)(disk + EXT2_BLOCK_SIZE);
        struct ext2_group_desc *group_desc = (struct ext2_group_desc *)(disk + 1024 + EXT2_BLOCK_SIZE);

}

